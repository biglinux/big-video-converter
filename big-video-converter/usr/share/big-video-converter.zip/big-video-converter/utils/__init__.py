"""
Utility functions for video conversion processes.
"""

# Utils package initialization
