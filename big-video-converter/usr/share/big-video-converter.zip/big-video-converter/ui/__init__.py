"""
User interface components for the application.
"""
